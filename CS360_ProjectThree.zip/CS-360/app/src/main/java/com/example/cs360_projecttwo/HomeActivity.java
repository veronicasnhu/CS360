package com.example.cs360_projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity {

    private EditText goalWeightInput;
    private EditText dailyWeightInput;

    private TextView progressMessage;
    private TextView progressPercent;
    private TextView motivationMessage;
    private TextView currentWeightText;
    private TextView currentWeightDate;

    private ProgressBar progressBar;

    private DatabaseHelper databaseHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        goalWeightInput = findViewById(R.id.editGoalWeight);
        dailyWeightInput = findViewById(R.id.editDailyWeight);

        currentWeightText = findViewById(R.id.textCurrentWeight);
        currentWeightDate = findViewById(R.id.textCurrentWeightDate);

        progressMessage = findViewById(R.id.textProgressMessage);
        progressPercent = findViewById(R.id.textProgressPercent);
        motivationMessage = findViewById(R.id.textMotivationMessage);
        progressBar = findViewById(R.id.progressBar);

        Button editGoalButton = findViewById(R.id.buttonUpdateGoal);
        Button logWeightButton = findViewById(R.id.buttonSaveWeight);
        Button recentEntriesButton = findViewById(R.id.buttonRecentEntries);
        TextView smsSettingsLink = findViewById(R.id.buttonAccountSettings);
        Button fullHistoryButton = findViewById(R.id.buttonViewHistory);

        databaseHelper = new DatabaseHelper(this);

        // Get the user that is currently logged in.
        userId = getIntent().getIntExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(
                    this,
                    R.string.message_account_error,
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        loadGoal();

        editGoalButton.setOnClickListener(v -> updateGoal());

        logWeightButton.setOnClickListener(v -> saveWeight());

        recentEntriesButton.setOnClickListener(
                v -> showRecentEntries()
        );

        smsSettingsLink.setOnClickListener(v -> {
            Intent intent = new Intent(
                    HomeActivity.this,
                    SmsActivity.class
            );

            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        fullHistoryButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    HomeActivity.this,
                    HistoryActivity.class
            );

            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Refresh the Home screen after changes are made in History.
        if (userId != -1) {
            loadCurrentWeight();
            updateProgress();
        }
    }

    private void loadGoal() {
        Double goalWeight =
                databaseHelper.getGoal(userId);

        if (goalWeight != null) {
            goalWeightInput.setText(
                    String.valueOf(goalWeight)
            );
        }
    }

    private void updateGoal() {
        String goalText =
                goalWeightInput.getText().toString().trim();

        if (goalText.isEmpty()) {
            Toast.makeText(
                    this,
                    R.string.message_enter_goal,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {
            double goalWeight =
                    Double.parseDouble(goalText);

            if (goalWeight <= 0) {
                Toast.makeText(
                        this,
                        R.string.message_invalid_goal,
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (databaseHelper.updateGoal(
                    userId,
                    goalWeight
            )) {
                Toast.makeText(
                        this,
                        R.string.message_goal_updated,
                        Toast.LENGTH_SHORT
                ).show();

                updateProgress();
            }

        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    R.string.message_invalid_goal,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void saveWeight() {
        String weightText =
                dailyWeightInput.getText().toString().trim();

        if (weightText.isEmpty()) {
            Toast.makeText(
                    this,
                    R.string.message_enter_weight,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {
            double weight =
                    Double.parseDouble(weightText);

            if (weight <= 0) {
                Toast.makeText(
                        this,
                        R.string.message_invalid_weight,
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            Double goalWeight =
                    databaseHelper.getGoal(userId);

            Double previousWeight =
                    getPreviousWeight();

            // Save the weight with the current date and time.
            Date now = new Date();

            String date = new SimpleDateFormat(
                    "MM/dd/yyyy",
                    Locale.getDefault()
            ).format(now);

            String time = new SimpleDateFormat(
                    "h:mm a",
                    Locale.getDefault()
            ).format(now);

            boolean saved =
                    databaseHelper.addWeight(
                            userId,
                            date,
                            time,
                            weight
                    );

            if (saved) {
                Toast.makeText(
                        this,
                        R.string.message_weight_saved,
                        Toast.LENGTH_SHORT
                ).show();

                dailyWeightInput.setText("");

                loadCurrentWeight();
                updateProgress();

                // Send an SMS if this entry reaches the goal.
                sendGoalSmsIfNeeded(
                        weight,
                        previousWeight,
                        goalWeight
                );

            } else {
                Toast.makeText(
                        this,
                        R.string.message_weight_save_failed,
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    R.string.message_invalid_weight,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private Double getPreviousWeight() {
        Cursor cursor =
                databaseHelper.getLatestWeight(userId);

        Double previousWeight = null;

        if (cursor.moveToFirst()) {
            previousWeight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow("weight")
            );
        }

        cursor.close();

        return previousWeight;
    }

    private void sendGoalSmsIfNeeded(
            double currentWeight,
            Double previousWeight,
            Double goalWeight
    ) {
        if (goalWeight == null) {
            return;
        }

        if (!databaseHelper.isSmsEnabled(userId)) {
            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        String phoneNumber =
                databaseHelper.getPhoneNumber(userId);

        if (phoneNumber == null
                || phoneNumber.trim().isEmpty()) {
            return;
        }

        Cursor cursor =
                databaseHelper.getFirstWeight(userId);

        if (!cursor.moveToFirst()) {
            cursor.close();
            return;
        }

        double startingWeight = cursor.getDouble(
                cursor.getColumnIndexOrThrow("weight")
        );

        cursor.close();

        boolean currentGoalReached =
                hasReachedGoal(
                        startingWeight,
                        goalWeight,
                        currentWeight
                );

        boolean previousGoalReached =
                previousWeight != null
                        && hasReachedGoal(
                        startingWeight,
                        goalWeight,
                        previousWeight
                );

        // Only send when the user first crosses the goal.
        if (currentGoalReached
                && !previousGoalReached) {

            try {
                SmsManager smsManager =
                        getSystemService(
                                SmsManager.class
                        );

                if (smsManager != null) {
                    smsManager.sendTextMessage(
                            phoneNumber,
                            null,
                            getString(
                                    R.string.sms_goal_message
                            ),
                            null,
                            null
                    );

                    Toast.makeText(
                            this,
                            R.string.message_sms_sent,
                            Toast.LENGTH_SHORT
                    ).show();
                }

            } catch (
                    SecurityException
                    | IllegalArgumentException
                    | UnsupportedOperationException e
            ) {
                Toast.makeText(
                        this,
                        R.string.message_sms_send_failed,
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }

    private boolean hasReachedGoal(
            double startingWeight,
            double goalWeight,
            double weight
    ) {
        if (goalWeight < startingWeight) {
            return weight <= goalWeight;

        } else if (goalWeight > startingWeight) {
            return weight >= goalWeight;

        } else {
            return Math.abs(
                    weight - goalWeight
            ) < 0.01;
        }
    }

    private void loadCurrentWeight() {
        Cursor cursor =
                databaseHelper.getLatestWeight(userId);

        if (cursor.moveToFirst()) {
            double weight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow("weight")
            );

            String date = cursor.getString(
                    cursor.getColumnIndexOrThrow("entry_date")
            );

            String time = cursor.getString(
                    cursor.getColumnIndexOrThrow("entry_time")
            );

            currentWeightText.setText(
                    getString(
                            R.string.weight_display,
                            weight
                    )
            );

            currentWeightDate.setText(
                    getString(
                            R.string.history_date_time,
                            date,
                            time
                    )
            );

        } else {
            currentWeightText.setText(
                    R.string.current_weight_none
            );

            currentWeightDate.setText(
                    R.string.current_weight_date_none
            );
        }

        cursor.close();
    }

    private void showRecentEntries() {
        Cursor cursor =
                databaseHelper.getAllWeights(userId);

        StringBuilder recentEntries =
                new StringBuilder();

        int count = 0;

        // Show up to three recent weight entries.
        while (count < 3 && cursor.moveToNext()) {
            String date = cursor.getString(
                    cursor.getColumnIndexOrThrow("entry_date")
            );

            String time = cursor.getString(
                    cursor.getColumnIndexOrThrow("entry_time")
            );

            double weight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow("weight")
            );

            recentEntries
                    .append(date)
                    .append(" ")
                    .append(time)
                    .append("\n")
                    .append(
                            getString(
                                    R.string.weight_display,
                                    weight
                            )
                    );

            count++;

            if (count < 3 && !cursor.isLast()) {
                recentEntries.append("\n\n");
            }
        }

        cursor.close();

        if (count == 0) {
            recentEntries.append(
                    getString(
                            R.string.message_no_entries
                    )
            );
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.title_recent_entries)
                .setMessage(recentEntries.toString())
                .setPositiveButton(
                        R.string.button_ok,
                        null
                )
                .show();
    }

    private void updateProgress() {
        Double goalWeight =
                databaseHelper.getGoal(userId);

        // A goal is needed before progress can be calculated.
        if (goalWeight == null) {
            progressBar.setProgress(0);

            progressPercent.setText(
                    R.string.progress_zero
            );

            progressMessage.setText(
                    R.string.message_set_goal
            );

            motivationMessage.setText(
                    R.string.message_progress_start
            );

            return;
        }

        Cursor firstCursor =
                databaseHelper.getFirstWeight(userId);

        Cursor latestCursor =
                databaseHelper.getLatestWeight(userId);

        // The user also needs at least one weight entry.
        if (!firstCursor.moveToFirst()
                || !latestCursor.moveToFirst()) {

            progressBar.setProgress(0);

            progressPercent.setText(
                    R.string.progress_zero
            );

            progressMessage.setText(
                    R.string.message_first_weight
            );

            motivationMessage.setText(
                    R.string.message_progress_start
            );

            firstCursor.close();
            latestCursor.close();
            return;
        }

        double startingWeight =
                firstCursor.getDouble(
                        firstCursor.getColumnIndexOrThrow("weight")
                );

        double currentWeight =
                latestCursor.getDouble(
                        latestCursor.getColumnIndexOrThrow("weight")
                );

        firstCursor.close();
        latestCursor.close();

        double totalChange =
                Math.abs(
                        startingWeight - goalWeight
                );

        double completedChange;

        // Support both weight-loss and weight-gain goals.
        if (goalWeight < startingWeight) {
            completedChange =
                    startingWeight - currentWeight;

        } else {
            completedChange =
                    currentWeight - startingWeight;
        }

        int percent;

        if (totalChange == 0) {
            if (Math.abs(
                    currentWeight - goalWeight
            ) < 0.01) {
                percent = 100;

            } else {
                percent = 0;
            }

        } else {
            percent = (int) Math.round(
                    (completedChange / totalChange)
                            * 100
            );
        }

        // Keep progress between 0 and 100.
        percent = Math.max(
                0,
                Math.min(
                        100,
                        percent
                )
        );

        boolean goalReached =
                hasReachedGoal(
                        startingWeight,
                        goalWeight,
                        currentWeight
                );

        if (goalReached) {
            progressBar.setProgress(100);

            progressPercent.setText(
                    getString(
                            R.string.progress_percent,
                            100
                    )
            );

            progressMessage.setText(
                    R.string.message_goal_reached
            );

            motivationMessage.setText(
                    R.string.message_progress_goal
            );

        } else {
            double remaining =
                    Math.abs(
                            currentWeight - goalWeight
                    );

            progressBar.setProgress(percent);

            progressPercent.setText(
                    getString(
                            R.string.progress_percent,
                            percent
                    )
            );

            progressMessage.setText(
                    getString(
                            R.string.message_weight_remaining,
                            remaining
                    )
            );

            // Change the message as the user gets closer to the goal.
            if (percent >= 75) {
                motivationMessage.setText(
                        R.string.message_progress_almost_there
                );

            } else if (percent >= 50) {
                motivationMessage.setText(
                        R.string.message_progress_halfway
                );

            } else if (percent > 0) {
                motivationMessage.setText(
                        R.string.message_progress_making_progress
                );

            } else {
                motivationMessage.setText(
                        R.string.message_progress_start
                );
            }
        }
    }
}