package com.example.cs360_projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.editUsername);
        passwordInput = findViewById(R.id.editPassword);

        Button loginButton = findViewById(R.id.buttonLogin);
        Button createAccountButton = findViewById(R.id.buttonCreateAccount);

        databaseHelper = new DatabaseHelper(this);

        loginButton.setOnClickListener(v -> login());
        createAccountButton.setOnClickListener(v -> createAccount());
    }

    private void login() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Enter a username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        int userId = databaseHelper.checkLogin(username, password);

        if (userId != -1) {
            openHome(userId);
        } else {
            Toast.makeText(this,
                    "Username or password is incorrect.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Enter a username and password.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.userExists(username)) {
            Toast.makeText(this,
                    "That username is already taken.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.createUser(username, password)) {
            int userId = databaseHelper.checkLogin(username, password);

            Toast.makeText(this,
                    "Account created.",
                    Toast.LENGTH_SHORT).show();

            openHome(userId);
        } else {
            Toast.makeText(this,
                    "Account could not be created.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void openHome(int userId) {
        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
        finish();
    }
}