package com.example.cs360_projecttwo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST = 1;

    private TextView smsStatus;
    private DatabaseHelper databaseHelper;
    private int userId;
    private String phoneNumber = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        smsStatus = findViewById(R.id.textSmsStatus);

        Button enableSmsButton = findViewById(R.id.buttonEnableSms);
        Button backButton = findViewById(R.id.buttonBackHistory);

        databaseHelper = new DatabaseHelper(this);

        // Get the logged-in user.
        userId = getIntent().getIntExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(
                    this,
                    R.string.message_account_error,
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        loadSmsSettings();

        enableSmsButton.setOnClickListener(v -> showPhoneDialog());
        backButton.setOnClickListener(v -> finish());
    }

    private void loadSmsSettings() {
        if (databaseHelper.isSmsEnabled(userId)) {
            smsStatus.setText(R.string.status_sms_on);
        } else {
            smsStatus.setText(R.string.status_sms_off);
        }
    }

    private void showPhoneDialog() {
        EditText phoneInput = new EditText(this);

        phoneInput.setHint(R.string.hint_phone_number);
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);

        String savedPhone = databaseHelper.getPhoneNumber(userId);

        if (savedPhone != null) {
            phoneInput.setText(savedPhone);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(R.string.title_phone_number);
        builder.setView(phoneInput);

        builder.setPositiveButton(
                R.string.button_continue,
                (dialog, which) -> {

                    phoneNumber = phoneInput
                            .getText()
                            .toString()
                            .trim();

                    if (phoneNumber.isEmpty()) {
                        Toast.makeText(
                                this,
                                R.string.message_enter_phone,
                                Toast.LENGTH_SHORT
                        ).show();
                    } else {
                        requestSmsPermission();
                    }
                }
        );

        builder.setNegativeButton(
                R.string.button_cancel,
                null
        );

        builder.show();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            saveSmsSetting();

        } else {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.SEND_SMS
                    },
                    SMS_PERMISSION_REQUEST
            );
        }
    }

    private void saveSmsSetting() {
        if (databaseHelper.saveSmsSettings(
                userId,
                phoneNumber,
                true
        )) {

            smsStatus.setText(
                    R.string.status_sms_on
            );

            Toast.makeText(
                    this,
                    R.string.message_sms_enabled,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults
    ) {
        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode == SMS_PERMISSION_REQUEST) {

            if (grantResults.length > 0
                    && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {

                saveSmsSetting();

            } else {

                databaseHelper.saveSmsSettings(
                        userId,
                        phoneNumber,
                        false
                );

                smsStatus.setText(
                        R.string.status_sms_off
                );

                Toast.makeText(
                        this,
                        R.string.message_sms_permission_denied,
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }
}