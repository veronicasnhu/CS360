package com.example.cs360_projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HistoryActivity extends AppCompatActivity {

    private EditText dateInput;
    private EditText timeInput;
    private EditText weightInput;
    private GridLayout weightGrid;
    private Button addEntryButton;

    private DatabaseHelper databaseHelper;
    private int userId;
    private int editingEntryId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        dateInput = findViewById(R.id.editDate);
        timeInput = findViewById(R.id.editTime);
        weightInput = findViewById(R.id.editWeight);
        weightGrid = findViewById(R.id.weightGrid);
        addEntryButton = findViewById(R.id.buttonAddEntry);

        Button smsButton = findViewById(R.id.buttonSmsSettings);

        databaseHelper = new DatabaseHelper(this);

        // Get the user that is currently logged in.
        userId = getIntent().getIntExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(
                    this,
                    R.string.message_account_error,
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        addEntryButton.setOnClickListener(v -> saveEntry());

        smsButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    HistoryActivity.this,
                    SmsActivity.class
            );

            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Reload the grid when returning to this screen.
        loadHistory();
    }

    private void saveEntry() {
        String date =
                dateInput.getText().toString().trim();

        String time =
                timeInput.getText().toString().trim();

        String weightText =
                weightInput.getText().toString().trim();

        if (weightText.isEmpty()) {
            Toast.makeText(
                    this,
                    R.string.message_enter_weight,
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Fill in the current date and time when left blank.
        Date now = new Date();

        if (date.isEmpty()) {
            date = new SimpleDateFormat(
                    "MM/dd/yyyy",
                    Locale.getDefault()
            ).format(now);
        }

        if (time.isEmpty()) {
            time = new SimpleDateFormat(
                    "h:mm a",
                    Locale.getDefault()
            ).format(now);
        }

        try {
            double weight =
                    Double.parseDouble(weightText);

            if (weight <= 0) {
                Toast.makeText(
                        this,
                        R.string.message_invalid_weight,
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            Double goalWeight =
                    databaseHelper.getGoal(userId);

            Double previousWeight =
                    getLatestWeight();

            boolean saved;

            // Create a new record or update the selected record.
            if (editingEntryId == -1) {
                saved = databaseHelper.addWeight(
                        userId,
                        date,
                        time,
                        weight
                );

            } else {
                saved = databaseHelper.updateWeight(
                        editingEntryId,
                        date,
                        time,
                        weight
                );
            }

            if (saved) {
                if (editingEntryId == -1) {
                    Toast.makeText(
                            this,
                            R.string.message_entry_added,
                            Toast.LENGTH_SHORT
                    ).show();

                } else {
                    Toast.makeText(
                            this,
                            R.string.message_entry_updated,
                            Toast.LENGTH_SHORT
                    ).show();
                }

                // Check the latest weight after saving the entry.
                Double currentWeight =
                        getLatestWeight();

                if (currentWeight != null) {
                    sendGoalSmsIfNeeded(
                            currentWeight,
                            previousWeight,
                            goalWeight
                    );
                }

                clearInputs();
                loadHistory();

            } else {
                Toast.makeText(
                        this,
                        R.string.message_entry_save_failed,
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    R.string.message_invalid_weight,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private Double getLatestWeight() {
        Cursor cursor =
                databaseHelper.getLatestWeight(userId);

        Double latestWeight = null;

        if (cursor.moveToFirst()) {
            latestWeight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow("weight")
            );
        }

        cursor.close();

        return latestWeight;
    }

    private void sendGoalSmsIfNeeded(
            double currentWeight,
            Double previousWeight,
            Double goalWeight
    ) {
        if (goalWeight == null) {
            return;
        }

        if (!databaseHelper.isSmsEnabled(userId)) {
            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        String phoneNumber =
                databaseHelper.getPhoneNumber(userId);

        if (phoneNumber == null
                || phoneNumber.trim().isEmpty()) {
            return;
        }

        Cursor cursor =
                databaseHelper.getFirstWeight(userId);

        if (!cursor.moveToFirst()) {
            cursor.close();
            return;
        }

        double startingWeight =
                cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight")
                );

        cursor.close();

        boolean currentGoalReached =
                hasReachedGoal(
                        startingWeight,
                        goalWeight,
                        currentWeight
                );

        boolean previousGoalReached =
                previousWeight != null
                        && hasReachedGoal(
                        startingWeight,
                        goalWeight,
                        previousWeight
                );

        // Only send when the new entry reaches the goal.
        if (currentGoalReached
                && !previousGoalReached) {

            try {
                SmsManager smsManager =
                        getSystemService(
                                SmsManager.class
                        );

                if (smsManager != null) {
                    smsManager.sendTextMessage(
                            phoneNumber,
                            null,
                            getString(
                                    R.string.sms_goal_message
                            ),
                            null,
                            null
                    );

                    Toast.makeText(
                            this,
                            R.string.message_sms_sent,
                            Toast.LENGTH_SHORT
                    ).show();
                }

            } catch (
                    SecurityException
                    | IllegalArgumentException
                    | UnsupportedOperationException e
            ) {
                Toast.makeText(
                        this,
                        R.string.message_sms_send_failed,
                        Toast.LENGTH_SHORT
                ).show();
            }
        }
    }

    private boolean hasReachedGoal(
            double startingWeight,
            double goalWeight,
            double weight
    ) {
        if (goalWeight < startingWeight) {
            return weight <= goalWeight;

        } else if (goalWeight > startingWeight) {
            return weight >= goalWeight;

        } else {
            return Math.abs(
                    weight - goalWeight
            ) < 0.01;
        }
    }

    private void startEditing(
            int entryId,
            String date,
            String time,
            double weight
    ) {
        editingEntryId = entryId;

        // Load the selected row into the input fields.
        dateInput.setText(date);
        timeInput.setText(time);
        weightInput.setText(
                String.valueOf(weight)
        );

        addEntryButton.setText(
                R.string.button_save_changes
        );
    }

    private void loadHistory() {

        // Keep the headers and remove old rows.
        while (weightGrid.getChildCount() > 3) {
            weightGrid.removeViewAt(3);
        }

        Cursor cursor =
                databaseHelper.getAllWeights(userId);

        while (cursor.moveToNext()) {

            int entryId = cursor.getInt(
                    cursor.getColumnIndexOrThrow("id")
            );

            String date = cursor.getString(
                    cursor.getColumnIndexOrThrow("entry_date")
            );

            String time = cursor.getString(
                    cursor.getColumnIndexOrThrow("entry_time")
            );

            double weight = cursor.getDouble(
                    cursor.getColumnIndexOrThrow("weight")
            );

            TextView dateText = createTextView(
                    getString(
                            R.string.history_date_time,
                            date,
                            time
                    )
            );

            TextView weightText = createTextView(
                    getString(
                            R.string.weight_display,
                            weight
                    )
            );

            // Add Edit and Delete buttons for each entry.
            LinearLayout actionLayout =
                    new LinearLayout(this);

            actionLayout.setOrientation(
                    LinearLayout.VERTICAL
            );

            Button editButton =
                    new Button(this);

            editButton.setText(
                    R.string.button_edit
            );

            Button deleteButton =
                    new Button(this);

            deleteButton.setText(
                    R.string.button_delete
            );

            LinearLayout.LayoutParams buttonParams =
                    new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                    );

            editButton.setLayoutParams(buttonParams);
            deleteButton.setLayoutParams(buttonParams);

            editButton.setOnClickListener(v ->
                    startEditing(
                            entryId,
                            date,
                            time,
                            weight
                    )
            );

            deleteButton.setOnClickListener(v -> {
                if (databaseHelper.deleteWeight(entryId)) {
                    Toast.makeText(
                            this,
                            R.string.message_entry_deleted,
                            Toast.LENGTH_SHORT
                    ).show();

                    if (entryId == editingEntryId) {
                        clearInputs();
                    }

                    loadHistory();

                } else {
                    Toast.makeText(
                            this,
                            R.string.message_entry_delete_failed,
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });

            actionLayout.addView(editButton);
            actionLayout.addView(deleteButton);

            GridLayout.LayoutParams actionParams =
                    new GridLayout.LayoutParams();

            actionParams.width = 0;

            actionParams.columnSpec =
                    GridLayout.spec(
                            GridLayout.UNDEFINED,
                            1f
                    );

            actionLayout.setLayoutParams(
                    actionParams
            );

            weightGrid.addView(dateText);
            weightGrid.addView(weightText);
            weightGrid.addView(actionLayout);
        }

        cursor.close();
    }

    private TextView createTextView(
            String text
    ) {
        TextView textView =
                new TextView(this);

        textView.setText(text);
        textView.setGravity(
                Gravity.CENTER
        );

        textView.setPadding(
                8,
                8,
                8,
                8
        );

        GridLayout.LayoutParams params =
                new GridLayout.LayoutParams();

        params.width = 0;

        params.columnSpec =
                GridLayout.spec(
                        GridLayout.UNDEFINED,
                        1f
                );

        textView.setLayoutParams(
                params
        );

        return textView;
    }

    private void clearInputs() {

        // Reset the form after adding, editing, or deleting an entry.
        dateInput.setText("");
        timeInput.setText("");
        weightInput.setText("");

        editingEntryId = -1;

        addEntryButton.setText(
                R.string.button_add_entry
        );
    }
}