package com.example.cs360_projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store account information and user settings.
        db.execSQL("CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password TEXT NOT NULL, " +
                "goal_weight REAL, " +
                "phone TEXT, " +
                "sms_enabled INTEGER DEFAULT 0)");

        // Store each weight entry for the logged-in user.
        db.execSQL("CREATE TABLE weights (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "entry_date TEXT NOT NULL, " +
                "entry_time TEXT NOT NULL, " +
                "weight REAL NOT NULL)");
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion
    ) {
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS users");

        onCreate(db);
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                new String[]{"id"},
                "username = ?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean exists = cursor.moveToFirst();

        cursor.close();

        return exists;
    }

    public boolean createUser(
            String username,
            String password
    ) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert(
                "users",
                null,
                values
        );

        return result != -1;
    }

    public int checkLogin(
            String username,
            String password
    ) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                new String[]{"id"},
                "username = ? AND password = ?",
                new String[]{username, password},
                null,
                null,
                null
        );

        int userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(
                    cursor.getColumnIndexOrThrow("id")
            );
        }

        cursor.close();

        return userId;
    }

    public boolean updateGoal(
            int userId,
            double goalWeight
    ) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("goal_weight", goalWeight);

        int rows = db.update(
                "users",
                values,
                "id = ?",
                new String[]{String.valueOf(userId)}
        );

        return rows > 0;
    }

    public Double getGoal(int userId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                new String[]{"goal_weight"},
                "id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null
        );

        Double goalWeight = null;

        if (cursor.moveToFirst() && !cursor.isNull(0)) {
            goalWeight = cursor.getDouble(0);
        }

        cursor.close();

        return goalWeight;
    }

    public boolean addWeight(
            int userId,
            String date,
            String time,
            double weight
    ) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("entry_date", date);
        values.put("entry_time", time);
        values.put("weight", weight);

        long result = db.insert(
                "weights",
                null,
                values
        );

        return result != -1;
    }

    public Cursor getAllWeights(int userId) {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                "weights",
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "id DESC"
        );
    }

    public Cursor getLatestWeight(int userId) {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                "weights",
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "id DESC",
                "1"
        );
    }

    public Cursor getFirstWeight(int userId) {
        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                "weights",
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "id ASC",
                "1"
        );
    }

    public boolean updateWeight(
            int entryId,
            String date,
            String time,
            double weight
    ) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("entry_date", date);
        values.put("entry_time", time);
        values.put("weight", weight);

        int rows = db.update(
                "weights",
                values,
                "id = ?",
                new String[]{String.valueOf(entryId)}
        );

        return rows > 0;
    }

    public boolean deleteWeight(int entryId) {
        SQLiteDatabase db = getWritableDatabase();

        int rows = db.delete(
                "weights",
                "id = ?",
                new String[]{String.valueOf(entryId)}
        );

        return rows > 0;
    }

    public boolean saveSmsSettings(
            int userId,
            String phone,
            boolean enabled
    ) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("phone", phone);
        values.put("sms_enabled", enabled ? 1 : 0);

        int rows = db.update(
                "users",
                values,
                "id = ?",
                new String[]{String.valueOf(userId)}
        );

        return rows > 0;
    }

    public String getPhoneNumber(int userId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                new String[]{"phone"},
                "id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null
        );

        String phone = null;

        if (cursor.moveToFirst() && !cursor.isNull(0)) {
            phone = cursor.getString(0);
        }

        cursor.close();

        return phone;
    }

    public boolean isSmsEnabled(int userId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                "users",
                new String[]{"sms_enabled"},
                "id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null
        );

        boolean enabled = false;

        if (cursor.moveToFirst()) {
            enabled = cursor.getInt(0) == 1;
        }

        cursor.close();

        return enabled;
    }
}